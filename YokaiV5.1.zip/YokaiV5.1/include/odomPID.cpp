/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       odomPID.cpp                                               */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  The program to calculate how to move to                   */
/*    a specific point in order to correct position during auton              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include <cmath>
#include "vex.h"
#include "Odom.cpp"

/*
  //--Variable and Function Definitions--//
  //variables
  - actualX    > coordinate of the physical robot on the field in the X direction
  - actualY    > coordinate of the physical robot on the field in the Y direction
  - globalO    > heading the physical robot is facing towards in degrees
  - globalORad > heading the physical robot is facing towards in radians
  - intendedX  > desired coordinate of the physical robot on the field in the X direction
  - intendedY  > desired coordinate of the physical robot on the field in the Y direction
  - intendedO  > desired heading the physical robot would face in degrees
  - errX       > error value between the actualX and intendedX values
  - errY       > error value between the actualY and intendedY values
  - errO       > error value between the globalO and intendedO values

  //functions
  - positionTrack(void) > runs the Odometry program
  - reduce(number to be reduced, bottom value, top value, value to reduce by)
    > Reduces a number to fit in between two desired values.  Mainly used
      to keep values inside the Unit Circle.
*/

//-------PID---------//
//-----------------Custom PID----------------//
void Forward(float inches, float speed, int Time) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg)-OLT);    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg)-ORT);    //right degree movement
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 10; //left motor speed
    float mp2 = 10; //right motor speed

    //--running PID--//
    int t = Brain.timer(msec);
    while ( (mp1 != 0 || mp2 != 0) && Brain.timer(msec) < t+Time) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement
        positionTrack();

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        mp1 = mp1 * (mp2/mp1);
        mp2 = mp2 * (mp1/mp2);
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 40) { mp1 = 40; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 40) { mp2 = 40; }   //if distance isn't close but speed is too low, keep going
        //running motors
        LMotor1.spin(forward, mp1, pct);
        LMotor2.spin(forward, mp1, pct);
        RMotor1.spin(reverse, mp2, pct);
        RMotor2.spin(reverse, mp2, pct);
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
} // PID for moving forward a specific amount of inches

void Backward(float inches, float speed) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement
        positionTrack();

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        mp1 = mp1 * (mp2/mp1);
        mp2 = mp2 * (mp1/mp2);
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 40) { mp1 = 40; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 40) { mp2 = 40; }   //if distance isn't close but speed is too low, keep going
        //running motors
        LMotor1.spin(reverse, mp1, pct);
        LMotor2.spin(reverse, mp1, pct);
        RMotor1.spin(forward, mp2, pct);
        RMotor2.spin(forward, mp2, pct);
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
} // PID for moving backward a specific amount of inches

void TurnLeft(float degrees, float speed, int Time) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    double DPI = ( 2.02*6.75*(3.141592653)*(degrees/360) ) * 41.6696578277;  //degrees per degree of orientation
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed
    bool s1 = true;
    bool s2 = true;

    //--running PID--//
    int t = Brain.timer(msec);
    while ((mp1 != 0 && mp2 != 0) && t+Time > Brain.timer(msec)) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement
        positionTrack();
        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        if ( (mp2 >= 50 && mp1 >= 50) || (mp2 <= 10 && mp1 <= 10) ) {
          mp1 = mp1 * (mp2/mp1);
          mp2 = mp2 * (mp1/mp2);
        }
        printf("%.2f, %.2f\n", mp1, mp2);
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0; s1 = false; }          //if distance is close, stop
        else if (mp1 <= 50 && mp1 >= 10) { mp1 = 50; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; s2 = false; }          //if distance is close, stop
        else if (mp2 <= 50 && mp2 >= 10) { mp2 = 50; }   //if distance isn't close but speed is too low, keep going
        //running motors
        if (s1) {
          LMotor1.spin(reverse, mp1, pct);
          LMotor2.spin(reverse, mp1, pct);
        }
        else {
          LMotor1.stop(hold);
          LMotor2.stop(hold);
        }
        
        if (s2) {
          RMotor1.spin(reverse, mp2, pct);
          RMotor2.spin(reverse, mp2, pct);
        }
        else {
          RMotor1.stop(hold);
          RMotor2.stop(hold);
        }
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
}

void TurnRight(float degrees, float speed, int Time) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    double DPI = ( 1.98*6.75*(3.141592653)*(degrees/360) ) * 41.6696578277;  //degrees per degree of orientation
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed
    bool s1 = true;
    bool s2 = true;

    //--running PID--//
    int t = Brain.timer(msec);
    while ((mp1 != 0 && mp2 != 0) && t+Time > Brain.timer(msec)) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement
        positionTrack();

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        if ( (mp2 >= 50 && mp1 >= 50) || (mp2 <= 10 && mp1 <= 10) ) {
          mp1 = mp1 * (mp2/mp1);
          mp2 = mp2 * (mp1/mp2);
        }
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0; s1 = false; }          //if distance is close, stop
        else if (mp1 <= 50 && mp1 >= 5) { mp1 = 50; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; s2 = false; }          //if distance is close, stop
        else if (mp2 <= 50 && mp2 >= 5) { mp2 = 50; }   //if distance isn't close but speed is too low, keep going
        //running motors
        if (s1) {
          LMotor1.spin(fwd, mp1, pct);
          LMotor2.spin(fwd, mp1, pct);
        }
        else {
          LMotor1.stop(hold);
          LMotor2.stop(hold);
        }
        
        if (s2) {
          RMotor1.spin(fwd, mp2, pct);
          RMotor2.spin(fwd, mp2, pct);
        }
        else {
          RMotor1.stop(hold);
          RMotor2.stop(hold);
        }
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
}

void ForwardNS(float inches, float speed) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    bool running = true;                  //running while loop
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement
        positionTrack();

        //running motors
        LMotor1.spin(forward, 100*speed, pct);
        LMotor2.spin(forward, 100*speed, pct);
        RMotor1.spin(reverse, 100*speed, pct);
        RMotor2.spin(reverse, 100*speed, pct);
    }
} // PID for moving forward a specific amount of inches and not slowing down

void BackwardNS(float inches, float speed) {
    //inches = inches to move
    //speed  = float speed

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    bool running = true;                  //running while loop
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement
        positionTrack();
        
        //running motors
        LMotor1.spin(reverse, 100*speed, pct);
        LMotor2.spin(reverse, 100*speed, pct);
        RMotor1.spin(fwd, 100*speed, pct);
        RMotor2.spin(fwd, 100*speed, pct);
    }
} // PID for moving forward a specific amount of inches and not slowing down

void Strafe(float inches, float speed, int Time) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OBT = std::abs(BTrack.position(deg));       //resetting left tracking wheel
    float track = std::abs(BTrack.rotation(deg)-OBT);    //left degree movement
    float mp1 = 10; //left motor speed
    float mp2 = 10; //right motor speed

    bool di = true;
    if (inches < 0) { di = false; }
    inches = fabs(inches);
    
    double DPI = inches * 41.6696578277;  //degrees per inch

    //--running PID--//
    int t = Brain.timer(msec);
    while ( (mp1 != 0 || mp2 != 0) && Brain.timer(msec) < t+Time) {
        //--updating variables
        if (di)  {track = std::abs(std::abs(BTrack.rotation(deg)) - OBT); }  //left degree movement 
        if (!di) {track = std::abs(std::abs(BTrack.rotation(deg)) + OBT); }  //left degree movement
        positionTrack();

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track) / DPI) * 100 * speed;
        mp2 = ((DPI - track) / DPI) * 100 * speed;
        mp1 = mp1 * (mp2/mp1);
        mp2 = mp2 * (mp1/mp2);
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 40) { mp1 = 40; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 40) { mp2 = 40; }   //if distance isn't close but speed is too low, keep going
        //running motors
        if (di) {
          LMotor1.spin(forward, mp1, pct);
          LMotor2.spin(reverse, mp1, pct);
          RMotor1.spin(forward, mp2, pct);
          RMotor2.spin(reverse, mp2, pct);
        }
        else {
          LMotor1.spin(reverse, mp1, pct);
          LMotor2.spin(fwd, mp1, pct);
          RMotor1.spin(reverse, mp2, pct);
          RMotor2.spin(fwd, mp2, pct);
        }
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
} // PID for moving forward a specific amount of inches



/*
  //--Method for moving to a specific XY--//
  - Takes the desired XY and turns toward
    while moving to that point. Uses the
    holonomic drive algorithm of
    "Throttle +/- Strafe +/- Turn"
*/
void Move(float intendedX, float intendedY, float intendedO, float Time, float slow, float curve, bool ch) {
  //--initializing variables
  float pi = 3.14159265358979323846264; //value of pi
  float errX = intendedX - actualX;
  float errY = intendedY - actualY;
  float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
  float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
  float track1 = std::abs(LTrack.rotation(deg)-OLT);    //left degree movement
  float track2 = std::abs(RTrack.rotation(deg)-ORT);    //right degree movement

  //getting the angle between the current coordinates and the intended coordinates
  float degr = reduce(atan2(errY, errX), 0, 2*pi, 2*pi);
  float turnO = 0;

  float D = sqrt( pow(errX, 2) + pow(errY, 2) );//distance between current coordinates and intended coordinates
  float Curve = .1 + curve;
  float oldD = D;

  bool cdir = true; //right
  if (globalORad || degr) {cdir = false;} //left

  //--PID loop that calculates values and motor speed
  //til distance is reached (less than half an inch away)
  int t = Brain.timer(msec);

  bool run = true;
  while ( run ) {
    //-updating variables
    positionTrack();
    errX = intendedX - actualX;
    errY = intendedY - actualY;
    D = sqrt( pow(errX, 2) + pow(errY, 2) );
    turnO = reduce(intendedO - globalO, -180, 180, 360);
    track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
    track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement

    float adegr = 0;
    if (!slow) {
      adegr = reduce( (atan2(errY, errX)+(pi/2))*(180/pi), -180, 180, 360);
      turnO = reduce(adegr - globalO, -180, 180, 360); 
    }

    float MP = 1;
    if (D/20 < 1) {
      MP = -pow((D/25)-1,4)+1.10;
    }
    if (MP > .85) {
      MP = .85;
    }
    if (!slow && MP <.7) {
      MP = .7;
    }
    MP *= 100;
    if (ch) {MP *= 1.4;}
    
    int c = 30;
    if (D < 2) { c = 2; }
    float turnD = turnO/c;
    if (turnD > .8) { turnD = .8; }
    else if (turnD < -.8) { turnD = -.8; }
    if (ch) {turnD *= .6;}
    float totalMovement = 1.1 - fabs(turnD*.8);
    if (D < .3) { totalMovement = 0; }

    degr = reduce(atan2(errX, errY), 0, 2*pi, 2*pi);
    
    float curve = (Curve) * D/oldD;

    float strafeD = sin(degr) + curve;
    if (strafeD > 1.5) {strafeD = 1.5;}
    else if (strafeD < -1.5) {strafeD = -1.5;}
    if (D < 10 && D > 3) {strafeD *= 1.3; }

    float throttle = cos(degr);
    if (throttle > 1) { throttle = 1; }
    if (throttle < -1) { throttle = -1; }

    float LM1 = throttle + strafeD + turnD;  //LMotor1 holonomic value
    float LM2 = throttle - strafeD + turnD;  //LMotor2 holonomic value
    float RM1 = throttle - strafeD - turnD;  //RMotor1 holonomic value
    float RM2 = throttle + strafeD - turnD;  //RMotor2 holonomic value

    //debuging
    printf("%.2f, %.2f, %.2f, %.2f, %.2f, %.2f\n", actualX, actualY, errX, errY, turnD, D);
    
    //stopping
    if (!ch && ((slow && D < .3 && turnD < .5) || Brain.timer(msec) > t+Time)) { run = false; }
    if (!ch && ((!slow && throttle <= 0) || Brain.timer(msec) > t+Time)) { run = false; }
    if (ch && ((slow && (sqrt( pow(-intendedX - actualX, 2) + pow(-intendedY - actualY, 2) )) < .3 && turnD < .5) || Brain.timer(msec) > t+Time)) { run = false; }

    //running motors
    LMotor1.spin(fwd,     LM1 * MP, pct );
    LMotor2.spin(fwd,     LM2 * MP, pct );
    RMotor1.spin(reverse, RM1 * MP, pct ); 
    RMotor2.spin(reverse, RM2 * MP, pct );
  }

  /*turnO = reduce(intendedO - globalO, -180, 180, 360);
  if(turnO > 1) { TurnLeft(turnO*.8, .3, turnO*50); }
  if(turnO < 1) { TurnRight(fabs(turnO)*.8, .3, turnO*50); }*/

  //stopping motors after movement is complete
  LMotor1.stop(brake);
  RMotor1.stop(brake);
  LMotor2.stop(brake);
  RMotor2.stop(brake);
  task::sleep(50);//letting it rest
}

void Correction(float intendedX, float intendedY, float intendedO, float Curve, bool ch, int ttt) {
  float turnO = reduce(intendedO - globalO, -180, 180, 360);
  float times = (std::abs(turnO)/90)*600;

  if (turnO > 35) {
    TurnRight(turnO-40, .7, times);
  }
  if (turnO < -35) {
    TurnLeft(std::abs(turnO)-40, .7, times);
  }

  float dist = sqrt( pow(intendedX-actualX, 2) + pow(intendedY-actualY, 2));
  float times2 = dist*60;
  if (ttt != 0) {times2 = ttt;}
  if ((dist > 1.5 || turnO > 1) && (intendedX != 1000 || intendedY != 1000)) {
    Move(intendedX, intendedY, intendedO, times2, true, Curve, ch);
  }
}

void PurePursuit(float loc[], float num) {
  
}