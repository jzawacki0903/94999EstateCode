/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       Odom.cpp                                                  */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  The program to calculate the specific coordinates of      */
/*    the bot on the field.                                                   */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"
#include <cmath>

//----Odometry Variables----//
//--stationary values
//booleanS
bool first = true;

//bot size
float botWidth = 13.5;
float botLength = 4.75;

//encoder stationary values
float IPD = 0.023998277215;//inches per degree of movement

//--calculated values
//encoder positions
double lastR = 0;
double lastL = 0;
double lastB = 0;
double currentR = 0;
double currentL = 0;
double currentB = 0;

//deltas (change since last run)
double deltaL = 0; //left encoder
double deltaR = 0; //right encoder
double deltaB = 0; //back encoder
double deltaA = 0; //change in angle

//locations
double localX = 0;
double localY = 0;
double globalX = 0;
double globalY = 0;

//actual locations
double lastActualX = 0;
double lastActualY = 0;
double actualX = 0;
double actualY = 0;

//orientation
double lastO = 0;
double globalO = 0;
double lastORad = 0;
double globalORad = 0;

//polar
double localPAngle = 0;
double localPLength = 0;
double globalPAngle = 0;
double globalPLength = 0;

//--Custom Functions--//
double reduce(double deg, double botm, double top, double minus) {
  while (deg > top || deg < botm) {
    if (deg > top) { deg -= minus; }
    else if (deg < botm) { deg += minus; }
  }

  return deg;
}


//----Odometry Code----//
//calculating minor sections
void getOrientation() {
  //global orientation
  float pi = 3.141592653589793238;
  globalORad = (currentL-currentR)/botWidth;
  globalO = reduce( (globalORad*180/pi) , 0, 360, 360);

  /*
  if (globalO > 350 && inertialDeg < 10) {
    inertialDeg  += 360;
    globalO = reduce( (globalO + inertialDeg) / 2, 0, 360, 360);
    globalORad = reduce(globalO*pi/180, 0, 2*pi, 2*pi);
  }
  else if (globalO < 10 && inertialDeg > 350) {
    globalO += 360;
    globalO = reduce( (globalO + inertialDeg) / 2, 0, 360, 360);
    globalORad = reduce(globalO*pi/180, 0, 2*pi, 2*pi);
  }
  else {
    globalO = (globalO + inertialDeg) / 2;
    globalORad = reduce(globalO*pi/180, 0, 2*pi, 2*pi);
  }

  globalO = Inertial10.heading(degrees);
  globalORad = globalO * (3.141592653589793238/180);
  */

  deltaA = (deltaL-deltaR)/botWidth; //change of angle
}

//updating values
void updateEncoderVariables() {
  //current inch values
  currentR = -1 * RTrack.rotation(deg) * IPD;
  currentL = -1 * LTrack.rotation(deg) * IPD;
  currentB = -BTrack.rotation(deg) * IPD;

  //delta updating
  deltaR = currentR - lastR;
  deltaL = currentL - lastL;
  deltaB = currentB - lastB;

  //updating last distance
  lastR = currentR;
  lastL = currentL;
  lastB = currentB;
}

//calculating position
void calculatePosition() {
  getOrientation();

  //calculating robot movment based on arc
  if (deltaA == 0) {
    localX = deltaB;
    localY = deltaR;
  }
  else {
    localX = (2*sin(deltaA/2)) * ((deltaB/deltaA)+botLength);
    localY = (2*sin(deltaA/2)) * ((deltaR/deltaA)+(botWidth/2));
  }

  //calculating polar coordinates
  if (localX == 0 && localY == 0) {
    localPAngle = 0;
    localPLength = 0;
  }
  else {
    localPAngle = atan2(localY, localX);
    localPLength = sqrt( pow(localX, 2) + pow(localY, 2) );
  }

  //converting polar to global
  globalPLength = localPLength;
  globalPAngle = localPAngle - lastORad - (deltaA/2);

  globalX = globalPLength * cos(globalPAngle);
  globalY = globalPLength * sin(globalPAngle);

  //calculating absolute posoition and orientation
  actualX = lastActualX + globalX;
  actualY = lastActualY + globalY;
  lastActualX = actualX;
  lastActualY = actualY;

  //preparing next calculation
  lastORad = globalORad;

  task::sleep(20);
}

void positionTrack() { //Background thread used to position track full time.
  if (first) {
    Inertial10.calibrate();
    Inertial10.setHeading(0, deg);
    RTrack.resetRotation();
    BTrack.resetRotation();
    LTrack.resetRotation();
    first = false;
    Brain.Screen.setPenColor(white);
  }
  updateEncoderVariables();
  calculatePosition();

  Brain.Screen.clearScreen();

  Brain.Screen.printAt(1, 20, "X: %.3fin Y: %.3fin O: %.3fdeg \n", actualX, actualY, globalO);
  Brain.Screen.printAt(1, 40, "LT: %.2f* BT: %.2f* RT: %.2f* \n", LTrack.position(degrees), -BTrack.position(degrees), RTrack.position(degrees));
  Brain.Screen.drawRectangle(150, 70, 140, 140);
  Brain.Screen.drawCircle(220, 140, 20);
  Brain.Screen.drawLine(220, 140, 
    220 + cos(reduce(globalORad+(3.141592653589793238*.5),0,2*3.141592653589793238,2*3.141592653589793238))*60,
    140 + sin(reduce(globalORad+(3.141592653589793238*.5),0,2*3.141592653589793238,2*3.141592653589793238))*60);
}