/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       CommonMethods.h                                           */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  The header file to call upon commonly used methods.       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"
#include <cmath>
#include <list>

//---------------------Methods-------------------------//
//--global variables
bool holdToggle = true; //bariable to tell if hold toggle is on or off
int whenPressed = 0; //variable to delay how often toggle can be pressed

//---------Common Methods---------//
void StopAll(bool Hold) {
  if (Hold) {
    LMotor1.stop(hold);
    LMotor2.stop(hold);
    RMotor1.stop(hold);
    RMotor2.stop(hold);
    Indexer.stop(hold);
    TopRoller.stop(hold);
    Intake1.stop(hold);
    Intake2.stop(hold);
  } //stopping all motors and setting them to hold
  else {
    LMotor1.stop(coast);
    LMotor2.stop(coast);
    RMotor1.stop(coast);
    RMotor2.stop(coast);
    Indexer.stop(coast);
    TopRoller.stop(coast);
    Intake1.stop(coast);
    Intake2.stop(coast);
  } //stopping all motors
} //method to stop all motors

void intake(bool direct) {
    //direction:  true for forward, false for backwards
    int spd = -100;
    if (direct) { spd = 100; }

    Intake1.spin(fwd, spd, volt);
    Intake2.spin(fwd, spd, volt);

}//method to intake intakes and indexer

void Index(int spd) {
    Indexer.spin(fwd, spd, volt);
}



void cycle(bool intake) {
    if (intake) {
      Intake1.spin(fwd, 100, volt);
      Intake2.spin(fwd, 100, volt);
    }
    Indexer.spin(fwd, 100, volt);
    TopRoller.spin(fwd, 100, volt);
}

void Stop(bool Hold) {

  if (Hold) {
      Intake1.stop(hold);
      Intake2.stop(hold);
  }//hold motors
  else {
      Indexer.stop(coast);
      TopRoller.stop(coast);
  }//coast motors

}//method to stop motors (excl base)



//----Driver Control Methods----//
int t = 0;
bool OIFirst = true;
void openIntakes() {
  if (OIFirst) {
    t = Brain.timer(msec);
    OIFirst = false;
  }
  if (Brain.timer(msec) < t + 100) {
    Intake1.spin(fwd, -8, volt);
    Intake2.spin(fwd, -8.5, volt);
  }
  else {
    Stop(true);
  }
}

bool victorySpin = false;
bool still = false;
void baseMovement() {
    //converting axis to exponential curve to make it go from very slow to very fast
    int Strafe = Controller1.Axis4.position();//input[count];
    int Throttle = Controller1.Axis3.position();//input[count+1];
    int Turn = Controller1.Axis1.position();//input[count+2];
    //double BR = .98;
    if ( (Throttle == 0) && (Strafe == 0) && (Turn == 0)) { still = true;}
    else { still = false;}

    //holonomic motor values
    float LM1 = (Throttle + Strafe + Turn);  //LMotor1 holonomic value
    float LM2 = (Throttle - Strafe + Turn);  //LMotor2 holonomic value
    float RM1 = (Throttle - Strafe - Turn);  //RMotor1 holonomic value
    float RM2 = (Throttle + Strafe - Turn);  //RMotor2 holonomic value

    //running motors
    if (!victorySpin && !still) {
        LMotor1.spin(fwd, LM1, pct );
        LMotor2.spin(fwd, LM2, pct );
        RMotor1.spin(reverse, RM1, pct ); 
        RMotor2.spin(reverse, RM2, pct );
    }
    else {
        LMotor1.stop(coast);
        LMotor2.stop(coast);
        RMotor1.stop(coast); 
        RMotor2.stop(coast);
    }

    task::sleep(20);
}//method used to check base control

void checkControls() {
    //checking for shift key
    bool shift = false;

    if (Controller1.ButtonR1.pressing()) { shift = true; }
    
    //-Peripheral Systems Control
    if (Controller1.ButtonL1.pressing()) {
      if (shift) {
        cycle(false);
      }
      else {
        cycle(true);
        OIFirst = true;
      }
    }
    else if (Controller1.ButtonL2.pressing()) {
      Index(-100);
      TopRoller.spin(fwd, -100, volt);
      openIntakes();
    }
    
    else if (Controller1.ButtonR2.pressing()) {
      if (shift) {
        //macro 1: 2x2
        cycle(true);
        OIFirst = true;
        wait(700, msec);
      }
      else {
        //making joysticks work
        victorySpin = false;

        TopRoller.spin(fwd, 7, pct);
        Indexer.spin(fwd, 7, pct);
        intake(true);
        OIFirst = true;
      }
    }
    else if (Controller1.ButtonUp.pressing()) {
      Indexer.spin(fwd, 30, pct);
      TopRoller.spin(fwd, 30, pct);
    }
    else {
      Stop(false);
      openIntakes();
    }//coasting the intakes, indexer, and top roller to a stop

    /*if (!Controller1.ButtonL1.pressing() && !Controller1.ButtonR2.pressing() && Controller1.Axis3.position() < -.3) {
      intake(false);
    }*/

}//method used to check the controller inputs other than base control


//-----------PID Help Methods-----------//
float Powers(int pow, int degr, int rotat) {
  float s = 0;
  float pi = 3.14159265358979323846264;

  if (pow == 1) { s = (pi)/4; }
  else { s = (3*pi)/4; }

  pow = 0;

  pow = (  cos(degr+s)*(-1*std::abs(rotat)+1)  ) / (  cos(pi/4)  );

  return pow;
}

bool Stuck() {
  if (LTrack.velocity(dps) == 0 && RTrack.velocity(dps) == 0) {
      return true;
  } 
  return false;
};