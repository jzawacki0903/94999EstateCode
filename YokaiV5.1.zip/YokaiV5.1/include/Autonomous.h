/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       Autonomous.h                                              */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  Class to contain our autonomous programs                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*------------How To Use------------//
  PID methods:
    -type in the method
    -the first number is inches, the float is speed in percentage.

  Motor Movement:
    -motor.spin(fwd/reverse, percentage, pct)
    -motor.stop()

  Stopping all motors:
    -StopAll() boolean true = hold, false = coast
*/

/*------------Completed Autonomi--------------//
  List of Autonomi:                       
  - left:                                 
    1 goal                                |
    2 goal                                |
    3 goal                                |
    2 goal w/mid                          |
    1 goal w/midside                      |
    2 goal w/midside                      |
    1 goal w/midside&mid                  |
  - right:                                
    1 goal                                |
    2 goal                                |
    3 goal                                |
    2 goal w/mid                          |
    1 goal w/mid                          |
    1 goal w/midside                      |
    1 goal w/midside&mid                  |
  - other:
    No Auton w/deploy                     |
    No Auton                              |
    Skills                                |
//------------------------- */

#include "vex.h"
#include "odomPID.cpp"

//----------------No Auton---------------//
void stopAll(bool Hold) {
  if (Hold) {
    LMotor1.stop(hold);
    LMotor2.stop(hold);
    RMotor1.stop(hold);
    RMotor2.stop(hold);
    Indexer.stop(hold);
    TopRoller.stop(hold);
    Intake1.stop(hold);
    Intake2.stop(hold);
  } //stopping all motors and setting them to hold
  else {
    LMotor1.stop(coast);
    LMotor2.stop(coast);
    RMotor1.stop(coast);
    RMotor2.stop(coast);
    Indexer.stop(coast);
    TopRoller.stop(coast);
    Intake1.stop(coast);
    Intake2.stop(coast);
  } //stopping all motors
} //method to stop all motors
void deploy() {
  Intake1.spin(fwd, 100, pct);
  Intake2.spin(fwd, 100, pct);
  Indexer.spin(fwd, -100, pct);
  TopRoller.spin(fwd, -100, pct);
  task::sleep(1400);
  stopAll(false);
}//no autonomous (still deploy)
void nAuton() {
}//no autonomous (no deploy)
//---------Common Methods---------//

void Intake(bool direct) {
    //direction:  true for forward, false for backwards
    int spd = -100;
    if (direct) { spd = 100; }

    Intake1.spin(fwd, spd, pct);
    Intake2.spin(fwd, spd, pct);

}//method to intake intakes and indexer

void index(int spd) {
    Indexer.spin(fwd, spd, pct);
}

void Cycle(int intake) {
    Intake1.spin(fwd, intake, pct);
    Intake2.spin(fwd, intake, pct);
    Indexer.spin(fwd, intake, pct);
    TopRoller.spin(fwd, intake, pct);
}

void revCycle(int intake, int cycl) {
    Intake1.spin(reverse, intake, pct);
    Intake2.spin(reverse, intake, pct);
    Indexer.spin(fwd, cycl, pct);
    TopRoller.spin(fwd, cycl, pct);
}

//--------------Left Auton--------------//
void g1Left() {
  deploy();
}//left one goal
void g3Left() {
  deploy();
  Forward(10, 1, 1300);
  Correction(0, 30, 280, 1.7, false, 0);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Forward(21, 1, 1000);
  Cycle(100);
  task::sleep(1200);
  stopAll(false);
  Intake1.spin(fwd, -100, pct);
  Intake2.spin(fwd, -100, pct);
  Backward(20, 1);
  stopAll(false);
  TurnLeft(135, .8, 1260); //144
  Forward(55, 4, 6000);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Correction(-46, 40, 180, .6, true, 2000);
  Forward(20, 2, 300);
  revCycle(-4, 100);
  task::sleep(1000);
  stopAll(false);
  Intake1.spin(fwd, -100, pct);
  Intake2.spin(fwd, -100, pct);
  Backward(20, .7);
  stopAll(false);
  TurnRight(9000, 1, 10000);
}//left three goals
void g2Left() {
  //deploy();
  g3Left();
}//left two goals
void g1MLeft() {
  deploy();
}//left one goal w/mid
void g2MLeft() {
  deploy();
  Forward(10, 1, 1300);
  Correction(0, 30, 280, 1.7, false, 0);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Forward(21, 1, 1000);
  Cycle(100);
  task::sleep(1200);
  stopAll(false);
  Intake1.spin(fwd, -100, pct);
  Intake2.spin(fwd, -100, pct);
  Backward(20, 1);
  stopAll(false);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Correction(5, 52, 60, 0, false, 900);
  Forward(13, .7, 1000);
  Strafe(45, .5, 1000);
  Strafe(-10, .5, 1000);
  Backward(10, .8);
}//left two goal w/mid
void g1MsLeft() {
  deploy();
}//left one goal w/midside
void g1MsMLeft() {
  deploy();
  Forward(10, 1, 1300);
  Correction(0, 30, 280, 1.7, false, 0);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Forward(21, 1, 1000);
  Cycle(100);
  task::sleep(1200);
  stopAll(false);
  Intake1.spin(fwd, -100, pct);
  Intake2.spin(fwd, -100, pct);
  Backward(20, 1);
  stopAll(false);
  Correction(14, 38, 60, 0, false, 0);
  Forward(30, .7, 1000);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Strafe(10, .5, 1000);
  Strafe(-5, .5, 1000);
  Backward(10, .8);
  //correction
  Forward(10, .7, 1000);
  Cycle(1000);
  task::sleep(1000);
  stopAll(false);
  Backward(10, .8);
}//left one goal w/midside&mid

//--------------Right Auton--------------//
void g1Right() {
  deploy();
  Forward(20, 1.4, 1000);
  Correction(-3, 34.36, 55, -.6, false, 0);
  Intake(false);
  Forward(10, 1.3, 800);
  wait(600, msec);
  Backward(10, .5);
  stopAll(false);
}//right one goal
void g2Right() {
  g1Right();
  Correction(42.61, 4.27, 122.53, 0, false, 0);
  Backward(9, 1.4);
  Forward(10, 1.3, 1000);
  Correction(-54.75, -35.94, 173.56, 0, false, 0);
  Intake(false);
  Forward(10, 1.3, 1500);
  wait(1, sec);
  Backward(10, .5);
  stopAll(false);
}//right two goals
void g3Right() {
  deploy();
  Forward(30, .8, 160000000);
  TurnLeft(87, .7, 80000000);
  Intake1.spin(reverse, 70, pct);
  Intake2.spin(reverse, 70, pct);
  Forward(19, 1.4, 1400);
  stopAll(false);
  Cycle(-1400);
  task::sleep(1000);
  stopAll(false);
  Intake1.spin(fwd, -100, pct);
  Intake2.spin(fwd, -100, pct);
  Backward(20.5, .55);
  stopAll(false);
  TurnLeft(152, .8, 1260);
  Forward(78, 2.4, 5000);
  TurnRight(40, .9, 1500000);
  Intake1.spin(fwd, 70, pct);
  Intake2.spin(fwd, 70, pct);
  Forward(51, 1, 1100);
  stopAll(false);
  revCycle(100, -100);
  task::sleep(700);
  stopAll(false);
  Intake1.spin(fwd, -100, pct);
  Intake2.spin(fwd, -100, pct);
  Backward(20, .7);
  stopAll(false);
  TurnRight(9000, 1, 10000);
}//right three goals
void g1MRight() {
  deploy();
}//right one goal w/mid
void g2MRight() {
  deploy();
  Intake(true);
  Forward(21, 1, 5);
  stopAll(false);
  //Backward(5, 1);
  TurnLeft(30, 1, 290);
  Forward(4, 1, 1);
  Cycle(-100);
  task::sleep(1000);
  stopAll(false);  
  Backward(10, 1);
  Correction(-10, -16, 1, 0, false, 0);
  TurnLeft(45, 1, 350);
  Forward(8, 1, 1);
  Cycle(100);
  task::sleep(800);
  stopAll(false);
  Backward(20, 1);
  TurnRight(135, 1, 700);
  Forward(35, 1, 8);
  TurnRight(45, 1, 350);
  Intake(true);
  Forward(10, 1, 4);
  task::sleep(200);
  Backward(20, 1);
}//right two goal w/mid
void g1MsRight() {
  deploy();
}//right one goal w/midside
void g1MsMRight() {
  deploy();
}//right one goal w/midside&mid

//------------Skills Auton-------------//
void field() {
  Intake1.spin(fwd, 100, pct);
  Intake2.spin(fwd, 100, pct);
  Indexer.spin(fwd, 5, pct);
  TopRoller.spin(fwd, 5, pct);
}
void outake(int speed) {
  Intake1.spin(fwd, -speed, pct);
  Intake2.spin(fwd, -speed, pct);
  Indexer.spin(fwd, -5, pct);
  TopRoller.spin(fwd, -5, pct);
}

void skills() {
  deploy();
  field();
  Forward(27, .8, 1800);
  TurnLeft(47, .6, 800);
  stopAll(false);
  Forward(24, 1, 1500);
  Cycle(-100);
  task::sleep(800);
  stopAll(false); //first goal
  outake(60);
  int t = 2000 + Brain.timer(msec); 
  printf("%.2i\n", t);
  while(t > Brain.timer(msec)) {
    int MP = -pow((t-Brain.timer(msec))/t, 2) + 1.1;
    positionTrack();
    
    LMotor1.spin(forward, -MP*60, pct);
    LMotor2.spin(forward, -MP*60, pct);
    RMotor1.spin(reverse, -MP*60, pct);
    RMotor2.spin(reverse, -MP*60, pct);

    task::sleep(20);
  }
  stopAll(false);
  TurnRight(108, .4, 1475); // from 3090
  //Correction(1000, 1000, 75, 1);
  field();
  Forward(43, .5, 1400); //55 to 58, 1600 to 1800
  task::sleep(100);
  TurnRight(70, 1, 1045); //71 to 69
  Forward(28, 1, 1600);
  stopAll(false);
  TurnLeft(8, 1, 300); //10 to 13
  Cycle(-40);
  task::sleep(600); //500 to 600
  stopAll(false); //center goal
  outake(60);
  TurnRight(9, 1, 300);
  t = 1100 + Brain.timer(msec);
  printf("%.2i\n", t);
  while(t > Brain.timer(msec)) {
    int MP = -pow((t-Brain.timer(msec))/t, 2) + 1.1;
    positionTrack();
    
    LMotor1.spin(forward, -MP*80, pct);
    LMotor2.spin(forward, -MP*80, pct);
    RMotor1.spin(reverse, -MP*80, pct);
    RMotor2.spin(reverse, -MP*80, pct); 

    task::sleep(20);
  }
  stopAll(false);
  TurnLeft(40, .6, 800);
  field();
  Forward(120,.8, 8000);
  stopAll(false);
  Cycle(-100);
  task::sleep(600);
  Backward(20, 1);
  stopAll(false);
  /**TurnRight(150, 1, 1800); //155 to 145, 1600 to 1800 
  Forward(60, 1, 2000);
  TurnLeft(13, 1, 500); //10 to 13
  Cycle(0);
  task::sleep(800);
  stopAll(false);//middle goal
  TurnRight(10, 1, 600);
  t = 800 + Brain.timer(msec);
  printf("%.2i\n", t);
  while(t > Brain.timer(msec)) {
    int MP = -pow((t-Brain.timer(msec))/t, 2) + 1.1;
    positionTrack();
    
    LMotor1.spin(forward, -MP*80, pct);
    LMotor2.spin(forward, -MP*80, pct);
    RMotor1.spin(reverse, -MP*80, pct);
    RMotor2.spin(reverse, -MP*80, pct);

    task::sleep(20);
  }
    LMotor1.spin(forward, 0, pct);
    LMotor2.spin(forward, 0, pct);
    RMotor1.spin(reverse, 0, pct);
    RMotor2.spin(reverse, 0, pct);
  task::sleep(2000);
  TurnLeft(40, 1, 550);
  field();
  Forward(80, 1, 3000);
  task::sleep(2000);
  stopAll(false);
  TurnLeft(40, 1, 350);
  Forward(30, 1, 2000);
  Cycle(-100);
  Backward(.5, 1);
  task::sleep(500); //600 to 500
  stopAll(false); //third goal
  task::sleep(400);
  outake(60);
  Backward(32, 1); //36 to 32
  stopAll(false);
  TurnRight(130, 1, 700); //150 to 155
  field();
  Forward(27, 1, 2700); //29 to 34
  task::sleep(200);
  stopAll(false);
  TurnLeft(100, 1, 600); //150 to 155
  Forward(34, 1, 3000);
  Backward(.5, 1); 
  Cycle(-100);
  task::sleep(600);
  stopAll(false); //fourth goal
  task::sleep(400);
  outake(60);
  Backward(38, 1);
  TurnRight(50, 1, 300);
  field();
  Forward(70, 1, 4000);
  stopAll(false);
  Cycle(-100);
  task::sleep(600);
  stopAll(false); //fifth goal
  task::sleep(400);
  outake(60);
  Backward(45, 1);*/
}//skills autonomous