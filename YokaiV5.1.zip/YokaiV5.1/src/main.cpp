/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  The Main Program for Yokai containing master control loop */
/*                                                                            */
/*----------------------------------------------------------------------------*/
float version = 5.207;

#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LMotor1              motor         17              
// RMotor1              motor         16              
// LMotor2              motor         13              
// RMotor2              motor         14              
// Indexer              motor         20              
// TopRoller            motor         2               
// Intake1              motor         9               
// Intake2              motor         11              
// Controller1          controller                    
// LTrack               encoder       C, D            
// RTrack               encoder       G, H            
// BTrack               encoder       A, B            
// Inertial10           inertial      10              
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "AutonSelector.cpp"
#include "CommonMethods.h"

//-------------Driver Program------------//
void Prog() {

  //---driver control period loop
  while(true) {
    //-Base Driving Control (Holonomic)-//
    baseMovement();

    //-Intakes, Indexer, and TopRoller Control-//
    checkControls();

    //Testing Autonomous
    if (Controller1.ButtonLeft.pressing()) {
      Correction(1.8, 46.33, 0, 0, false, 0);
    }//changing location
    if (Controller1.ButtonY.pressing()) {
      Strafe(10, 1, 1000);
      Strafe(-10, 1, 1000);
    }//changing location

    //Running and Displaying Odom
    if (display) {
      positionTrack();
      printf("%.2f, %.2f, %.2f\n", actualX, actualY, globalO);
      Controller1.Screen.clearScreen();
      Controller1.Screen.setCursor(1, 1);
      Controller1.Screen.print("%.3f", version);
    }

    //Sleeping to prevent brain power going over 9000
    vex::task::sleep(100);
  }//The driver control loop

}//driver control program


//--------------Main Method--------------//
int main() {
    displayButtons(1); //displaying autonomous selector
    bool autoStart = true;
    if (autoStart) {
      const char* str = "Left - 3 Goal - is running.";
      Competition.autonomous( g2MLeft ); //setting autonomous
      Brain.Screen.clearScreen(); //clearing screen
      Brain.Screen.setCursor(1,1); //starting at origin
      updateOutline(3); //creating white outline
      Brain.Screen.setPenColor(white); //showing which team is selected
      Brain.Screen.print(str); //displaying which auton is running
      autonSelected = false; //autonselected
      waitDisplay(); //waiting before starting odom
    }
    Competition.drivercontrol( Prog ); //setting the driver control program
    Brain.Screen.pressed(checkAuton);  //running autonomous selector

    Brain.Timer.reset(); //initiating brain timer
}