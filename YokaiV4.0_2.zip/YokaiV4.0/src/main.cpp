/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  The Main Program for Yokai containing master control loop */
/*    Version: 4.435                                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LMotor1              motor         17              
// RMotor1              motor         16              
// LMotor2              motor         13              
// RMotor2              motor         14              
// Indexer              motor         20              
// TopRoller            motor         2               
// Intake1              motor         9               
// Intake2              motor         11              
// Controller1          controller                    
// LTrack               encoder       C, D            
// RTrack               encoder       E, F            
// BTrack               encoder       A, B            
// Inertial10           inertial      10              
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "AutonSelector.cpp"
#include "CommonMethods.h"

//-------------Driver Program------------//
void Prog() {
  //---driver control period loop
  //variables
  int g[3] = {0, 0, 0};//array to hold position

  while(true) {
    //-Base Driving Control (Holonomic)-//
    baseMovement();

    //-Intakes, Indexer, and TopRoller Control-//
    checkControls();

    //Testing Autonomous
    if (Controller1.ButtonA.pressing()) {
      Correction(g[0], g[1], g[2], 3);
    }//correcting to location
    if (Controller1.ButtonB.pressing()) {
      g[0] = actualX;
      g[1] = actualY;
      g[2] = globalO;
      printf("%.2f\n", globalO);
    }//changing location

    //Running and Displaying Odom
    if (display) {
      positionTrack();
      //printf("O: %.2f\n", globalO);
      printf("I: %.2f\n", Inertial10.heading(deg));
      //.g3Right();
    }

    //Sleeping to prevent brain power going over 9000
    vex::task::sleep(100);
  }//The driver control loop

}//driver control program


//--------------Main Method--------------//
int main() {
    displayButtons(1); //displaying autonomous selector
    Competition.drivercontrol( Prog ); //setting the driver control program
    Brain.Screen.pressed(checkAuton);  //running autonomous selector

    Brain.Timer.reset(); //initiating brain timer
}