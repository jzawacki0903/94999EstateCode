using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor LMotor1;
extern motor RMotor1;
extern motor LMotor2;
extern motor RMotor2;
extern motor Indexer;
extern motor TopRoller;
extern motor Intake1;
extern motor Intake2;
extern controller Controller1;
extern encoder LTrack;
extern encoder RTrack;
extern encoder BTrack;
extern inertial Inertial10;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );