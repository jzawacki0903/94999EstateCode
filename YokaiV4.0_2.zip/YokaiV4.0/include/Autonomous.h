/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       Autonomous.h                                              */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  Class to contain our autonomous programs                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*------------How To Use------------//
  PID methods:
    -type in the method
    -the first number is inches, the float is speed in percentage.

  Motor Movement:
    -motor.spin(fwd/reverse, percentage, pct)
    -motor.stop()

  Stopping all motors:
    -StopAll() boolean true = hold, false = coast
*/

/*------------Completed Autonomi--------------//
  List of Autonomi:                       
  - left:                                 
    1 goal                                |
    2 goal                                |
    3 goal                                |
    2 goal w/mid                          |
    1 goal w/midside                      |
    2 goal w/midside                      |
    1 goal w/midside&mid                  |
  - right:                                
    1 goal                                |
    2 goal                                |
    3 goal                                |
    2 goal w/mid                          |
    1 goal w/mid                          |
    1 goal w/midside                      |
    1 goal w/midside&mid                  |
  - other:
    No Auton w/deploy                     |
    No Auton                              |
    Skills                                |
//------------------------- */

#include "vex.h"
#include "odomPID.cpp"

//----------------No Auton---------------//
void stopAll(bool Hold) {
  if (Hold) {
    LMotor1.stop(hold);
    LMotor2.stop(hold);
    RMotor1.stop(hold);
    RMotor2.stop(hold);
    Indexer.stop(hold);
    TopRoller.stop(hold);
    Intake1.stop(hold);
    Intake2.stop(hold);
  } //stopping all motors and setting them to hold
  else {
    LMotor1.stop(coast);
    LMotor2.stop(coast);
    RMotor1.stop(coast);
    RMotor2.stop(coast);
    Indexer.stop(coast);
    TopRoller.stop(coast);
    Intake1.stop(coast);
    Intake2.stop(coast);
  } //stopping all motors
} //method to stop all motors
void deploy() {
  Intake1.spin(fwd, 100, pct);
  Intake2.spin(fwd, 100, pct);
  Indexer.spin(fwd, 10, pct);
  TopRoller.spin(fwd, 10, pct);
  task::sleep(1400);
  stopAll(false);
}//no autonomous (still deploy)
void nAuton() {
}//no autonomous (no deploy)
//---------Common Methods---------//

void Intake(bool direct) {
    //direction:  true for forward, false for backwards
    int spd = -100;
    if (direct) { spd = 100; }

    Intake1.spin(fwd, spd, pct);
    Intake2.spin(fwd, spd, pct);

}//method to intake intakes and indexer

void index(int spd) {
    Indexer.spin(fwd, spd, pct);
}



void Cycle(bool intake) {
    if (intake) {
      Intake1.spin(fwd, 100, pct);
      Intake2.spin(fwd, 100, pct);
    }
    Indexer.spin(fwd, 15, volt);
    TopRoller.spin(fwd, 15, volt);
}

//--------------Left Auton--------------//
void g1Left() {
  deploy();
  Intake1.spin(fwd, 75, pct);
  Intake2.spin(fwd, 75, pct);
  trace();
  stopAll(false);
  TurnRight(9001, 1);
}//left one goal
void g2Left() {
  deploy();
  Intake1.spin(fwd, 75, pct);
  Intake2.spin(fwd, 75, pct);
  trace();
  stopAll(false);
  printf("1: %.2f, %.2f, %.2f", actualX, actualY, globalO);
  TurnLeft(100, .7);
  Forward(10, 1, 3);
  //Correction(0, 0, 244.33, 3);
  Intake1.spin(fwd, 75, pct);
  Intake2.spin(fwd, 75, pct);
  Forward(10, 1, 2);
  Cycle(true);
  task::sleep(600);
  stopAll(false);
  Intake1.spin(fwd, -50, pct);
  Intake2.spin(fwd, -50, pct);
  Backward(15, 1);
  stopAll(false);
  TurnRight(9001, 1);
}//left two goals
void g3Left() {
  deploy();
}//left three goals
void g1MLeft() {
  deploy();
}//left one goal w/mid
void g2MLeft() {
  deploy();
  Intake(true);
  trace();
  Backward(1, 1);
  task::sleep(700);
  stopAll(false);
  Backward(10, 1);
}//left two goal w/mid
void g1MsLeft() {
  deploy();
}//left one goal w/midside
void g1MsMLeft() {
  deploy();
}//left one goal w/midside&mid

//--------------Right Auton--------------//
void g1Right() {
  deploy();
  Intake(true);
  Forward(25, 1, 6);
  stopAll(false);
  Backward(4, 1);
  TurnLeft(30, 1);
  Forward(4, 1, 1);
  Cycle(false);
  task::sleep(1000);
  stopAll(false);  
  Backward(10, 1);
}//right one goal
void g2Right() {
  deploy();
  Intake(true);
  Forward(25, 1, 6);
  stopAll(false);
  Backward(4, 1);
  TurnLeft(30, 1);
  Forward(4, 1, 1);
  Cycle(false);
  task::sleep(1000);
  stopAll(false);  
  Backward(10, 1);
  Correction(-10, -30, 1, 6);
  TurnLeft(45, 1);
  Forward(8, 1, 1);
  Cycle(true);
  task::sleep(800);
  stopAll(false);
  Backward(10, 1);
}//right two goals
void g3Right() {
  deploy();
  while(true) {
    TurnRight(90*.9, .85);
    TurnLeft(90*.9, .85);
  }
}//right three goals
void g1MRight() {
  deploy();
}//right one goal w/mid
void g2MRight() {
  deploy();
  Intake(true);
  Forward(21, 1, 5);
  stopAll(false);
  //Backward(5, 1);
  TurnLeft(30, 1);
  Forward(4, 1, 1);
  Cycle(false);
  task::sleep(1000);
  stopAll(false);  
  Backward(10, 1);
  Correction(-10, -16, 1, 6);
  TurnLeft(45, 1);
  Forward(8, 1, 1);
  Cycle(true);
  task::sleep(800);
  stopAll(false);
  Backward(20, 1);
  TurnRight(135, 1);
  Forward(35, 1, 8);
  TurnRight(45, 1);
  Intake(true);
  Forward(10, 1, 4);
  task::sleep(200);
  Backward(20, 1);
}//right two goal w/mid
void g1MsRight() {
  deploy();
}//right one goal w/midside
void g1MsMRight() {
  deploy();
}//right one goal w/midside&mid

//------------Skills Auton-------------//
void field() {
  Intake1.spin(fwd, 100, pct);
  Intake2.spin(fwd, 100, pct);
  Indexer.spin(fwd, 5, pct);
  TopRoller.spin(fwd, 5, pct);
}
void outake(int speed) {
  Intake1.spin(fwd, -speed, pct);
  Intake2.spin(fwd, -speed, pct);
  Indexer.spin(fwd, -5, pct);
  TopRoller.spin(fwd, -5, pct);
}

void skills() {
  deploy();
  field();
  Forward(24, 1, 1300);
  TurnLeft(90*.8, 1);
  stopAll(false);
  Forward(19.5, 1, 1250);
  Backward(.5, 1);
  Cycle(false);
  task::sleep(500);
  stopAll(false); //first goal
  task::sleep(400);
  outake(60);
  Backward(60*.65, 1);
  stopAll(false);
  //Correction(0, 0, 42, 0);
  TurnRight(123*.9, 1); //HELL
  field();
  Forward(25, 1, 1400);
  TurnLeft(92*.85, 1); //90 to 93
  Forward(25, 1, 2000);
  stopAll(false);
  Backward(1, 1);
  Cycle(false);
  Backward(.5, 1);
  task::sleep(650);
  stopAll(false); //second goal
  task::sleep(400);
  outake(60);
  Backward(22*.7, 1);
  stopAll(false);
  TurnRight(90*.8, 1);
  field();
  Forward(40, 1, 2900);
  task::sleep(200);
  stopAll(false);
  TurnLeft(65*.75, 1);
  Forward(30, 1, 2000);
  Cycle(false);
  Backward(.5, 1);
  task::sleep(500); //600 to 500
  stopAll(false); //third goal
  task::sleep(400);
  outake(60);
  Backward(32, 1); //36 to 32
  stopAll(false);
  TurnRight(130*.9, 1); //150 to 155
  field();
  Forward(27, 1, 2700); //29 to 34
  task::sleep(200);
  stopAll(false);
  TurnLeft(100*.9, 1); //150 to 155
  Forward(34, 1, 3000);
  Backward(.5, 1); 
  Cycle(false);
  task::sleep(600);
  stopAll(false); //fourth goal
  task::sleep(400);
  outake(60);
  Backward(38, 1);
  TurnRight(50*.8, 1);
  field();
  Forward(70, 1, 4000);
  stopAll(false);
  Cycle(false);
  task::sleep(600);
  stopAll(false); //fifth goal
  task::sleep(400);
  outake(60);
  Backward(45, 1);
}//skills autonomous