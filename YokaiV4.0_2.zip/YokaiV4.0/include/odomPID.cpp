/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       odomPID.cpp                                               */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 24 2021                                               */
/*    Description:  The program to calculate how to move to                   */
/*    a specific point in order to correct position during auton              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include <cmath>
#include "vex.h"
#include "Odom.cpp"

/*
  //--Variable and Function Definitions--//
  //variables
  - actualX    > coordinate of the physical robot on the field in the X direction
  - actualY    > coordinate of the physical robot on the field in the Y direction
  - globalO    > heading the physical robot is facing towards in degrees
  - globalORad > heading the physical robot is facing towards in radians
  - intendedX  > desired coordinate of the physical robot on the field in the X direction
  - intendedY  > desired coordinate of the physical robot on the field in the Y direction
  - intendedO  > desired heading the physical robot would face in degrees
  - errX       > error value between the actualX and intendedX values
  - errY       > error value between the actualY and intendedY values
  - errO       > error value between the globalO and intendedO values

  //functions
  - positionTrack(void) > runs the Odometry program
  - reduce(number to be reduced, bottom value, top value, value to reduce by)
    > Reduces a number to fit in between two desired values.  Mainly used
      to keep values inside the Unit Circle.
*/

/*
  //--Method for moving to a specific XY--//
  - Takes the desired XY and turns toward
    while moving to that point. Uses the
    holonomic drive algorithm of
    "Throttle +/- Strafe +/- Turn"
*/
void Move(float intendedX, float intendedY, float Time) {
  //--initializing variables
  float pi = 3.14159265358979323846264; //value of pi
  float errX = intendedX - actualX;
  float errY = intendedY - actualY;

  //getting the angle between the current coordinates and the intended coordinates
  float degr = 0;
  degr = reduce(atan2(errY, errX), 0, 2*pi, 2*pi);

  //getting error in heading in terms of radians, 
  //reducing it between -pi and pi in order to know which direction to turn
  float D = sqrt( pow(errX, 2) + pow(errY, 2) );//distance between current coordinates and intended coordinates
  float DS = D; //starting distance

  //--PID loop that calculates values and motor speed
  //til distance is reached (less than half an inch away)
  int t = Brain.Timer.value();
  while ( D > 1 && Brain.Timer.value() < t+Time ) {
      //-updating variables
      positionTrack();
      errX = intendedX - actualX;
      errY = intendedY - actualY;
      D = sqrt( pow(errX, 2) + pow(errY, 2) );
      degr = reduce(atan2(errY, errX) + (pi/4), 0, 2*pi, 2*pi);
      
      //gets the percentage of how close the robot is to the intended point.
      float MP = (D/DS);
      if (MP < .3) {
        MP = .3;
      }//if the motor speed gets down to 30%, don't go any slower

      /*
        -calculating motor values
      */
      float P1 = -cos(degr);
      float P2 = sin(degr);
      float s = fmax(fabs(P1), fabs(P2));

      float LM1 = P2/s * MP;
      float RM1 = P1/s * MP;
      float LM2 = P1/s * MP;
      float RM2 = P2/s * MP;

      //float RM2 = ( ((sin(degr) + cos(degr)) * MP) - (cos(degr) * MP) ) * 100; //Back Right Motor
      //float LM1 = ( ((sin(degr) + cos(degr)) * MP) + (cos(degr) * MP) ) * 100; //Front Left Motor
      //float LM2 = ( ((sin(degr) - cos(degr)) * MP) + (cos(degr) * MP) ) * 100; //Back Left Motor
      //float RM1 = ( ((sin(degr) - cos(degr)) * MP) - (cos(degr) * MP) ) * 100; //Front Right Motor

      //debuging
      printf("FL: %.2f FR: %.2f BL: %.2f BR: %.2f\n", 
        LM1, RM1, LM2, RM2
      );

      //running motors
      LMotor1.spin(forward, LM1*100, pct);
      LMotor2.spin(forward, LM2*100, pct);
      RMotor1.spin(reverse, RM1*100, pct);
      RMotor2.spin(reverse, RM2*100, pct);
      task::sleep(20);//letting it rest
  }


  //stopping motors after movement is complete
  LMotor1.stop(brake);
  RMotor1.stop(brake);
  LMotor2.stop(brake);
  RMotor2.stop(brake);
  task::sleep(50);//letting it rest
}









//-------PID---------//
//-----------------Custom PID----------------//
void Forward(float inches, float speed, int Time) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    int t = Brain.timer(msec);
    while ( (mp1 != 0 || mp2 != 0) && Brain.timer(msec) < t+Time) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 50) { mp1 = 50; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 50) { mp2 = 50; }   //if distance isn't close but speed is too low, keep going
        //running motors
        LMotor1.spin(forward, mp1, pct);
        LMotor2.spin(forward, mp1, pct);
        RMotor1.spin(reverse, mp2, pct);
        RMotor2.spin(reverse, mp2, pct);
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
} // PID for moving forward a specific amount of inches

void Backward(float inches, float speed) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 50) { mp1 = 50; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 50) { mp2 = 50; }   //if distance isn't close but speed is too low, keep going
        //running motors
        LMotor1.spin(reverse, mp1, pct);
        LMotor2.spin(reverse, mp1, pct);
        RMotor1.spin(forward, mp2, pct);
        RMotor2.spin(forward, mp2, pct);
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(50);//let it rest
} // PID for moving backward a specific amount of inches

void TurnLeft(float degrees, float speed) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg)) - OLT;    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg)) - ORT;    //right degree movement
    double DPI = degrees * 6.18182;                   //degrees of movement
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement


        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;} //if distance is close, stop
        else if (mp1 <= 20) { mp1 = 20; }  //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; } //if distance is close, stop
        else if (mp2 <= 20) { mp2 = 20; }  //if distance isn't close but speed is too low, keep going
        //running motors
        LMotor1.spin(reverse, mp1, pct);
        LMotor2.spin(reverse, mp1, pct);
        RMotor1.spin(reverse, mp2, pct);
        RMotor2.spin(reverse, mp2, pct);
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(100);//let it rest
} // PID for turning a specific amount of degrees left

void TurnRight(float degrees, float speed) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg)) - OLT;    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg)) - ORT;    //right degree movement
    double DPI = degrees * 6.18182;                   //degrees of movement
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement


        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;} //if distance is close, stop
        else if (mp1 <= 20) { mp1 = 20; }  //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; } //if distance is close, stop
        else if (mp2 <= 20) { mp2 = 20; }  //if distance isn't close but speed is too low, keep going
        //running motors
        LMotor1.spin(fwd, mp1, pct);
        LMotor2.spin(fwd, mp1, pct);
        RMotor1.spin(fwd, mp2, pct);
        RMotor2.spin(fwd, mp2, pct);
    }

    //stopping motors
    LMotor1.stop(brake);
    RMotor1.stop(brake);
    LMotor2.stop(brake);
    RMotor2.stop(brake);
    task::sleep(100);//let it rest
} // PID for turning a specific amount of degrees right

void ForwardNS(float inches, float speed) {
    //inches = inches to move
    //speed  = true: fast || false: slow

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    bool running = true;                  //running while loop
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 50) { mp1 = 50; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 50) { mp2 = 50; }   //if distance isn't close but speed is too low, keep going

        //running motors
        LMotor1.spin(forward, 100*speed, pct);
        LMotor2.spin(forward, 100*speed, pct);
        RMotor1.spin(reverse, 100*speed, pct);
        RMotor2.spin(reverse, 100*speed, pct);
    }
} // PID for moving forward a specific amount of inches and not slowing down

void BackwardNS(float inches, float speed) {
    //inches = inches to move
    //speed  = float speed

    //initializing variables and resetting motors
    float OLT = std::abs(LTrack.position(deg));       //resetting left tracking wheel
    float ORT = std::abs(RTrack.position(deg));       //resetting right tracking wheel
    float track1 = std::abs(LTrack.rotation(deg));    //left degree movement
    float track2 = std::abs(RTrack.rotation(deg));    //right degree movement
    bool running = true;                  //running while loop
    double DPI = inches * 41.6696578277;  //degrees per inch
    float mp1 = 1; //left motor speed
    float mp2 = 1; //right motor speed

    //--running PID--//
    while (mp1 != 0 || mp2 != 0) {
        //--updating variables
        track1 = std::abs(std::abs(LTrack.rotation(deg)) - OLT);   //left degree movement
        track2 = std::abs(std::abs(RTrack.rotation(deg)) - ORT);   //right degree movement

        //--running motors
        //getting motor speeds
        mp1 = ((DPI - track1) / DPI) * 100 * speed;
        mp2 = ((DPI - track2) / DPI) * 100 * speed;
        //testing if a side has reached it's distance
        if (mp1 <= 1) { mp1 = 0;}           //if distance is close, stop
        else if (mp1 <= 50) { mp1 = 50; }   //if distance isn't close but speed is too low, keep going
        if (mp2 <= 1) { mp2 = 0; }          //if distance is close, stop
        else if (mp2 <= 50) { mp2 = 50; }   //if distance isn't close but speed is too low, keep going
        
        //running motors
        LMotor1.spin(reverse, 100*speed, pct);
        LMotor2.spin(reverse, 100*speed, pct);
        RMotor1.spin(fwd, 100*speed, pct);
        RMotor2.spin(fwd, 100*speed, pct);
    }
} // PID for moving forward a specific amount of inches and not slowing down





void Correction(float intendedX, float intendedY, float intendedO, float Time) {
  intendedO = reduce(intendedO - Inertial10.heading(deg), -180, 180, 360);
  //if (sqrt( pow(intendedX-actualX, 2) + pow(intendedY-actualY, 2) ) > 1.5) {
  //  Move(intendedX, intendedY, Time);
  //}
  float spd = .7;
  float adjustment = .8;
  if (std::abs(intendedO) < 45) {
    spd = (std::abs(intendedO)/45) * .7;
  }
  else {
    adjustment = .9;
  }

  if (intendedO > 2) {
    TurnRight(intendedO*adjustment, spd);
  }
  else if (intendedO < -2) {
    TurnLeft(std::abs(intendedO)*adjustment*.978, spd);
  }
}



float l1[]  = {13, 03, 00, 25, 24, 00, 31, 27, 00, 37, 27, -14, 39, 27, -21, 41, 27, -31, 41, 27, -31, 41, 27, -33, 41, 27, -32, 40, 29, -33, 41, 27, -33, 41, 27, -33, 41, 29, -32, 42, 27, -33, 42, 27, -32, 40, 27, -33, 40, 27, -34, 40, 27, -34, 41, 27, -33, 42, 27, -33, 40, 27, -34, 42, 27, -34, 40, 27, -33, 40, 27, -33, 40, 27, -33, 40, 27, -34, 37, 27, -33, 35, 27, -34, 35, 27, -34, 24, 29, -33, 14, 29, -32, 07, 32, -29, 04, 37, -28, 00, 40, -24, 00, 43, -14, 00, 53, 00, 00, 59, 00, 00, 81, 00, 00, 85, 00, 00, 85, 00, 00, 85, 00, 00, 85, 00, 00, 85, 00, 00, 85, 00, 00, 85, 00, 00, 70, 11, 00, 70, 15, 00, 69, 29, 00, 66, 29, 00, 66, 25, 00, 66, 00, 00, 66, 00, 00, 66, 00, 00, 56, 00, 00, 56, 00, 00, 56, 00, 00, 56, 00, 00, 46, 00, 00, 37, 00, 00, 19, 00, 00, 00, 00};
float l2[]  = {00, 00, -02, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, -29, 00, 00, -73, 00, 00, -89, 00, 00, -86, 00, 00, -81, 00, 00, -81, 00, 00, -81, 00, 00, -81, 00, 00, -81, 00, 00, -79, 00, 00, -79, 00, 00, -79, 00, 00, -79, 00, 00, -80, 00, 00, -78, 00, 00, -78, 00, 00, -78, 00, 00, -79, 00, 00, -79, 00, 00, -77, 00, 00, -79, 00, 00, -78, 00, 00, -76, 00, 00, -70, 00, 00, -66, 00, 00, -67, 00, 00, -65, 00, 00, -64, 00, 00, -64, 00, 00, -62, 00, 00, -53, -07};
float l3[]  = {00, -48, -12, 00, -48, -8, 00, -48, 00, 00, -48, 00, 00, -49, 00, 00, -48, 00, 00, -49, 00, -01, -49, 00, -03, -49, 00, -14, -48, 00, -19, -49, 00, -36, -48, -07, -43, -43, -18, -44, -37, -23, -48, -35, -26, -52, -30, -29, -58, -22, -29, -66, -15, -29, -70, -13, -30, -71, -8, -29, -74, -06, -29, -77, -01, -29, -77, -02, -30, -77, -02, -29, -77, -01, -30, -77, 00, -29, -77, 00, -29, -78, 00, -29, -77, 00, -29, -77, 00, -29, -77, 00, -30, -77, 00, -30, -77, 00, -29, -77, 00, -30, -76, 07, -26, -74, 10, -25, -51, 32, 00, -26, 44, 00, -24, 46, 00, -8, 51, 00, 00, 51, 00, 00, 51, 00, 00, 48, 00, 00, 45, 00, 00, 43, 00, 00, 43, 00, 00, 40, 00, 00, 37, 00, 00, 36, 00, 00, 37, 00, 00, 37, 00, 00, 37, -03, 00, 37, -17, 00, 37, -25, 00, 36, -46, 00, 36, -48, 00, 35, -48, 00, 36, -47, 00, 36, -34, 00, 44, -14, 00, 48, -02, 00, 48, 00, 00, 49, 00, 00, 49, 00, 00, 49, 00, 00, 48, 00, 00, 49, 00, 00, 49, 00, 00, 49, 00, 00, 43, 00, 00, 20, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00};
float l4[]  = {00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, -14, 00, 00, -29, 00, 00, -35, 00, 00, -39, 00, 00, -37, 00, 00, -39, 00, 00, -39, 00, 00, -39, 00, 00, -40, 00, 00, -40, 00, 00, -44, 00, 00, -45, 00, 00, -48, 00, 00, -51, 00, 00, -51, 00, 00, -55, 00, 00, -62, 00, 00, -64, 00, 00, -64, 00, 00, -63, 00, 00, -63, 00, 00, -63, 00, 00, -64, 00, 00, -63, 00, 00, -64, 00, 00, -63, 00,};
float l5[]  = {00, -60, 00, 00, -59, 00, 00, -59, 00, 00, -56, 00, 00, -54, 00, -03, -28, 00, -03, -18, 00, -02, -02, 18, -02, 00, 40, -03, 00, 48, -03, 00, 51, -03, 00, 54, -02, 00, 57, -02, 00, 62, -03, 00, 73, -11, 00, 77, -14, 00, 77, -33, 00, 84, -34, 00, 85, -33, 00, 85, -37, 00, 87, -40, 00, 87, -53, 00, 87, -56, 00, 87, -56, 00, 87, -57, 00, 87, -57, 00, 87, -63, 00, 86, -66, 00, 86, -66, 00, 86, -67, 20, 86, -70, 22, 86, -71, 24, 86, -71, 25, 86, -71, 26, 86, -70, 33, 84, -70, 37, 79, -71, 42, 70, -71, 43, 66, -71, 43, 66, -71, 51, 54, -71, 51, 43, -71, 51, 24, -73, 51, 05, -73, 51, 00, -75, 49, 00, -75, 49, 00, -75, 49, 00, -75, 49, 00, -71, 51, 00, -57, 64, 00, -51, 67, 00, -38, 70, 00, -34, 71, 00, -34, 71, 00, -11, 70, 07, -8, 70, 13, 00, 70, 16, 00, 68, 16, 00, 68, 16, 00, 64, 16, 00, 63, 16, 00, 62, 07, 00, 62, 00, 00, 60, 00, 00, 58, 00, 00, 55, 00, 00, 54, 00, 00, 54, 00, 00, 54, 00, 00, 54, 00, 00, 53, 00, 01, 37, 00, 20, 29, 00, 20, 29, 00, 29, 23, 00, 29, 22, 00, 29, 20, 00, 30, 20, 00, 30, 18, 00, 32, 00, 00, 36, 00, 00, 36, 00, 00, 36, 00, 00, 37, 00, 00, 37, 07, 00, 36, 05, 00, 37, 05, 00, 37, 00, 00, 36, 00, 00, 36, 00, 00, 37, 00, 00, 36, 00, 00, 35, 00, 00, 35, 00, 00, 36, 00, 00, 35, 00, 00, 18, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00};
float l6[]  = {00, -23, 00, 00, -35, 00, 00, -63, 00, 00, -81, 00, 00, -81, 00, 00, -81, 00, 00, -77, 00, 00, -76, 00, 00, -76, 00, 00, -77, 00, 00, -76, 00, 00, -75, 00, 00, -77, 00, 00, -76, 00, 00, -77, 00, 00, -75, 00, 00, -77, 00, 00, -75, 00, 00, -65, 00, 00, -56, 00, 00, 00, 00, 00, 00, 00, 00, 00, 00};

void trace() {
  int num = sizeof(l1)/sizeof(l1[0]);
  printf("num: %i \n", num);
  for (int i = 0; i < num; i+=3) {
    float Throttle = l1[i+1];
    float Strafe = l1[i];
    float Turn = l1[i+2];

    float LM1 = (Throttle + Strafe + Turn);  //LMotor1 holonomic value
    float LM2 = (Throttle - Strafe + Turn);  //LMotor2 holonomic value
    float RM1 = (Throttle - Strafe - Turn);  //RMotor1 holonomic value
    float RM2 = (Throttle + Strafe - Turn);  //RMotor2 holonomic value

    //running motors
    LMotor1.spin(fwd, LM1, pct );
    LMotor2.spin(fwd, LM2, pct );
    RMotor1.spin(reverse, RM1, pct ); 
    RMotor2.spin(reverse, RM2, pct );
    
    task::sleep(35);
  }
  Intake1.spin(fwd, -30, pct);
  Intake2.spin(fwd, -30, pct);
  Indexer.spin(fwd, 100, pct);
  TopRoller.spin(fwd, 100, pct);
  
  num = sizeof(l2)/sizeof(l2[0]);
  printf("num: %i \n", num);
  for (int i = 0; i < num; i+=3) {
    float Throttle = l2[i+1];
    float Strafe = l2[i];
    float Turn = l2[i+2];

    float LM1 = (Throttle + Strafe + Turn);  //LMotor1 holonomic value
    float LM2 = (Throttle - Strafe + Turn);  //LMotor2 holonomic value
    float RM1 = (Throttle - Strafe - Turn);  //RMotor1 holonomic value
    float RM2 = (Throttle + Strafe - Turn);  //RMotor2 holonomic value

    //running motors
    LMotor1.spin(fwd, LM1, pct );
    LMotor2.spin(fwd, LM2, pct );
    RMotor1.spin(reverse, RM1, pct ); 
    RMotor2.spin(reverse, RM2, pct );
    
    task::sleep(38);
  }
  Intake1.spin(fwd, 0, pct);
  Intake2.spin(fwd, 0, pct);
  Indexer.spin(fwd, 0, pct);
  TopRoller.spin(fwd, 0, pct);
}

void trace2() {
  int num = sizeof(l3)/sizeof(l3[0]);
  printf("num: %i \n", num);
  for (int i = 0; i < num; i+=3) {
    float Throttle = l3[i+1];
    float Strafe = l3[i];
    float Turn = l3[i+2];

    float LM1 = (Throttle + Strafe + Turn);  //LMotor1 holonomic value
    float LM2 = (Throttle - Strafe + Turn);  //LMotor2 holonomic value
    float RM1 = (Throttle - Strafe - Turn);  //RMotor1 holonomic value
    float RM2 = (Throttle + Strafe - Turn);  //RMotor2 holonomic value

    //running motors
    LMotor1.spin(fwd, LM1, pct );
    LMotor2.spin(fwd, LM2, pct );
    RMotor1.spin(reverse, RM1, pct ); 
    RMotor2.spin(reverse, RM2, pct );
    
    task::sleep(43);
  }
  Intake1.spin(fwd, 100, pct);
  Intake2.spin(fwd, 100, pct);
  Indexer.spin(fwd, 100, pct);
  TopRoller.spin(fwd, 100, pct);
}