/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       AutonSelector.cpp                                         */
/*    Author:       Dawson Pent                                               */
/*    Created:      Jan 25 2021                                               */
/*    Description:  Class to display and calculate Autonomous Selector        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"
#include "Autonomous.h"
#include <string>

vex::competition Competition;

/*--------------------------//
  List of Autonomi:
  - left:
    1 goal
    2 goal
    3 goal (optional which side)
    1 goal w/mid
    2 goal w/mid
    1 goal w/midside
    1 goal w/midside&mid
    No auton w/deploy
    No auton
  - right:
    1 goal
    2 goal
    3 goal (optional which side)
    1 goal w/mid
    2 goal w/mid
    1 goal w/midside
    1 goal w/midside&mid
    No auton w/deploy
    No auton
//------------------------- */

//Initializing important variables
bool Color = false; //variable to define if color is Blue (true) or Red (false)
bool autonSelected = true; //variable to tell whether the auton button is pressed or not
int tab = 1; //variable to tell which tab is active

//--------------Running Display---------//
//--create outline
void updateOutline(int input) {
  //input 1=left, 2=right, anything else=skills

  //setting color of the outline
  switch(input) {
    case 1: Brain.Screen.setPenColor(cyan); break; //left
    case 2: Brain.Screen.setPenColor(orange); break; //right
    default: Brain.Screen.setPenColor(white); break; //skills
  }

  //creating outline
  Brain.Screen.setPenWidth(8);
  Brain.Screen.drawLine(0, 0, 480, 0); //top left to top right
  Brain.Screen.drawLine(480, 0, 480, 272); //top right to bottom right
  Brain.Screen.drawLine(0, 0, 0, 272); //top left to bottom left
  Brain.Screen.drawLine(0, 241, 480, 241); //bottom left to bottom right
}//will create the outer outline

//-remove display to show Odom screen
bool display = false;//boolean for when to turn Odom on
void waitDisplay() {
  task::sleep(1000);
  Brain.Screen.clearScreen();
  display = true;
}//when Auton selected, let status screen display then display Odom

//--display buttons
void displayButtons(int input) {
  //input 1=left, 2=right, anything else=skills

  //---restarting
  Brain.Screen.clearScreen();
  //getting height of letters
  Brain.Screen.setPenWidth(1);
  int ht = Brain.Screen.getStringHeight("B"); //height of leters
  int wd = Brain.Screen.getStringWidth("B"); //width of leters
  tab = input; //variable to tell which tab is active

  //---create tabs
  Brain.Screen.setPenWidth(3);
  Brain.Screen.setPenColor(color(104, 104, 104));
  switch (input) {
    case 1:
      Brain.Screen.drawRectangle(5,5,100,60);                              //left
      Brain.Screen.drawRectangle(105,5,100,60, color(174, 174, 174));      //right
      Brain.Screen.drawRectangle(205,5,100,60, color(174, 174, 174));      //skills
      break;
    case 2:
      Brain.Screen.drawRectangle(5,5,100,60, color(174, 174, 174));        //left
      Brain.Screen.drawRectangle(105,5,100,60);                            //right
      Brain.Screen.drawRectangle(205,5,100,60, color(174, 174, 174));      //skills
      break;
    default:
      Brain.Screen.drawRectangle(5,5,100,60, color(174, 174, 174));        //left
      Brain.Screen.drawRectangle(105,5,100,60, color(174, 174, 174));      //right
      Brain.Screen.drawRectangle(205,5,100,60);                            //skills
      break;
  }//creating tab rectangles and graying out unselected tabs
  //-creating tab text
  Brain.Screen.setPenWidth(1);
  switch (input) {
    case 1:
      Brain.Screen.setPenColor(white);
      Brain.Screen.drawRectangle(8,58,96,7, white); //creating selected rectangle
      Brain.Screen.printAt(( (87-(wd*4))/2 ) + 12, ( (60-ht)/2 ) + 20, false, "Left"); //printing tab text
      Brain.Screen.setPenColor(black); //making unselected tabs black
      Brain.Screen.printAt(( (87-(wd*5))/2 ) + 113, ( (60-ht)/2 ) + 20, false, "Right"); //printing tab text
      Brain.Screen.printAt(( (87-(wd*6))/2 ) + 213, ( (60-ht)/2 ) + 20, false, "Skills"); //printing tab text
      break; //left
    case 2: 
      Brain.Screen.setPenColor(white);
      Brain.Screen.drawRectangle(107,58,97,7, white); //creating selected rectangle
      Brain.Screen.setPenColor(black); //making unselected tabs black
      Brain.Screen.printAt(( (87-(wd*4))/2 ) + 12, ( (60-ht)/2 ) + 20, false, "Left"); //printing tab text
      Brain.Screen.setPenColor(white); //making selected tab white
      Brain.Screen.printAt(( (87-(wd*5))/2 ) + 113, ( (60-ht)/2 ) + 20, false, "Right"); //printing tab text
      Brain.Screen.setPenColor(black); //making unselected tabs black
      Brain.Screen.printAt(( (87-(wd*6))/2 ) + 213, ( (60-ht)/2 ) + 20, false, "Skills"); //printing tab text
      break; //right
    default: 
      Brain.Screen.setPenColor(white);
      Brain.Screen.drawRectangle(207,58,98,7, white); //creating selected rectangle
      Brain.Screen.setPenColor(black); //making unselected tabs black
      Brain.Screen.printAt(( (87-(wd*4))/2 ) + 12, ( (60-ht)/2 ) + 20, false, "Left"); //printing tab text
      Brain.Screen.printAt(( (87-(wd*5))/2 ) + 113, ( (60-ht)/2 ) + 20, false, "Right"); //printing tab text
      Brain.Screen.setPenColor(white); //making selected tab white
      Brain.Screen.printAt(( (87-(wd*6))/2 ) + 213, ( (60-ht)/2 ) + 20, false, "Skills"); //printing tab text
      break; //skills
  }//creating tab selected rectangle
  
  //---create buttons
  //initialization
  Brain.Screen.setPenWidth(1);
  int x = 30; int y = 90; int w = 80; int h = (ht*2.4); //size of the button rectangle
  const char* string = ""; //variable to hold button string
  std::string str = ""; //variable to hold length of string
  //creation
  switch (input) {
    case 1: //left
      //initializing values
      Brain.Screen.setPenColor(white);

      //creating rectangles and printing text on each one
      for (int z = 0; z < 9; z++) {
        switch (z) {
          case 0:
            string = "1G";
            break;
          case 1:
            string = "2G";
            break;
          case 2:
            string = "3G";
            break;
          case 3:
            string = "1GM";
            break;
          case 4:
            string = "2GM";
            break;
          case 5:
            string = "1GMs";
            break;
          case 6:
            string = "1GMsM";
            break;
          case 7:
            string = "Depl";
            break;
          case 8:
            string = "None";
            break;
        }
        if (z == 6) { x = 30; y += (h*1.5); } //at edge of the screen, move down a line
        str = string; //get string length
        w = (str.length()*wd) + 20; //get width of button
        Brain.Screen.drawRectangle(x, y, w, h); //draw the button
        Brain.Screen.printAt(( (w-(wd*str.length()))/2 ) + x, ( (h-ht)/2 ) + (y+(ht)), true, string); //draw button text in middle of button
        x += w + 10; //move over for next button
      }//displaying autonomous buttons
      break; //left

    case 2: //right
      //initializing values
      Brain.Screen.setPenColor(white);

      //creating rectangles and printing text on each one
      for (int z = 0; z < 9; z++) {
        switch (z) {
          case 0:
            string = "1G";
            break;
          case 1:
            string = "2G";
            break;
          case 2:
            string = "3G";
            break;
          case 3:
            string = "1GM";
            break;
          case 4:
            string = "2GM";
            break;
          case 5:
            string = "1GMs";
            break;
          case 6:
            string = "1GMsM";
            break;
          case 7:
            string = "Depl";
            break;
          case 8:
            string = "None";
            break;
        }
        if (z == 6) { x = 30; y += (h*1.5); } //at edge of the screen, move down a line
        str = string; //get string length
        w = (str.length()*wd) + 20; //get width of button
        Brain.Screen.drawRectangle(x, y, w, h); //draw the button
        Brain.Screen.printAt(( (w-(wd*str.length()))/2 ) + x, ( (h-ht)/2 ) + (y+(ht)), true, string); //draw button text in middle of button
        x += w + 10; //move over for next button
      }//displaying autonomous buttons
      break; //right

    default: //skills
      //initializing values
      Brain.Screen.setPenColor(white);

      //creating button
      y = y - 10; //move button up
      Brain.Screen.drawRectangle(x, y, w+100, h ); //draw button
      Brain.Screen.printAt(( ((w+100)-(wd*12))/2 ) + x + (wd*4) - 40, ( (y-ht)/2 ) + (y-7), true, "Skills Auton"); //draw button text in middle of button
      break; //skills
  }//creating the buttons
  
}//will display the buttons to choose auton


//-----------Pressing Detection---------//
void checkAuton() {
  //--initializing values of where the screen was pressed
  int xPos = Brain.Screen.xPosition();
  int yPos = Brain.Screen.yPosition();
  
  //--testing where the screen was pressed
  std::string string = ""; //variable to hold button text
  const char* str = ""; //variable to print the running text
  bool Pressed = false; //variable to tell if a button is pressed
  int fx = 30; //the first x of a button
  int sx = 0; //the second x of a button
  int y = 90; //tells which level of buttons was pressed
  int auton = 0; //selected autonomous
  int wd = Brain.Screen.getStringWidth("B"); //width of leters
  int ht = Brain.Screen.getStringHeight("B"); //height of leters

  //sensing tab pressing
  if (yPos <= 65 && autonSelected) {
    if (xPos <= 105) {
      displayButtons(1); //flip display to left tab buttons
      Color = false; //changin which team we are on for program automation
    }//if the x value of the left tab is pressed
    else if (xPos >= 106 && xPos <= 204) {
      displayButtons(2); //flip display to right tab buttons
      Color = true; //changing which team we are on for program automation
    }//if the x value of the right tab is pressed
    else if (xPos >= 205) {
      displayButtons(3); //flip display to skills tab buttons
      Color = false; //making team red for program automation
    }//if the x value of the skills tab is pressed
  }//if the y values of a tab is pressed and the auton isn't selected yet

  //sensing button pressing
  else if (autonSelected) {
      switch (tab) {
        case 1: //left tab
          //getting the button location
          for (int z = 0; z < 9; z++) {
              switch (z) {
                case 0:
                  string = "1G"; //Button text
                  str = "Left - 1 Goal - is running."; //Brain text
                  auton = 0; //auton selected
                  break;
                case 1:
                  string = "2G";
                  str = "Left - 2 Goals - is running.";
                  auton = 1;
                  break;
                case 2:
                  string = "3G";
                  str = "Left - 3 Goals - is running.";
                  auton = 2;
                  break;
                case 3:
                  string = "1GM";
                  str = "Left - 1 goal w/mid - is running.";
                  auton = 3;
                  break;
                case 4:
                  string = "2GM";
                  str = "Left - 2 goal w/mid - is running.";
                  auton = 4;
                  break;
                case 5:
                  string = "1GMs";
                  str = "Left - 1 goal w/midside - is running.";
                  auton = 5;
                  break;
                case 6:
                  string = "1GMsM";
                  str = "Left - 1 goal w/midside&mid - is running.";
                  auton = 6;
                  break;
                case 7:
                  string = "Depl";
                  str = "Left - No Auton w/Deploy - is running.";
                  auton = 7;
                  break;
                case 8:
                  string = "None";
                  str = "Left - No Auton - is running.";
                  auton = 8;
                  break;
              }//getting the button location and text
              //declaring the first and second x for the button
              if (z == 6) { y += (ht*2.4) * 1.5; fx = 30; } //if these buttons are not pressed, move down to next line
              sx = fx + (string.length()*wd) + 20; //the x for the right side of the button
              if ( (xPos >= fx && xPos <= sx) && (yPos >= y && yPos <= (y + (ht*2.4))) ) { Pressed = true; z = 100; } //testing if this button is pressed and stopping loop if so
              fx += ((string.length()*wd) + 20) + 10; //moving the x to the next button on the line
          }//figuring out if/which button is pressed
          if (Pressed) {
            switch (auton) {
                case 0:
                  Competition.autonomous( g1Left ); //setting autonomous
                  break;
                case 1:
                  Competition.autonomous( g2Left ); //setting autonomous
                  break;
                case 2:
                  Competition.autonomous( g3Left ); //setting autonomous
                  break;
                case 3:
                  Competition.autonomous( g1MLeft ); //setting autonomous
                  break;
                case 4:
                  Competition.autonomous( g2MLeft ); //setting autonomous
                  break;
                case 5:
                  Competition.autonomous( g1MsLeft ); //setting autonomous
                  break;
                case 6:
                  Competition.autonomous( g1MsMLeft ); //setting autonomous
                  break;
                case 7:
                  Competition.autonomous( deploy ); //setting autonomous
                  break;
                case 8:
                  Competition.autonomous( nAuton ); //setting autonomous
                  break;
            }//setting the correct autonomous
            Brain.Screen.clearScreen(); //clearing screen
            Brain.Screen.setCursor(1,1); //starting at origin
            updateOutline(3); //creating white outline
            Brain.Screen.setPenColor(white); //showing which team is selected
            Brain.Screen.print(str); //displaying which auton is running
            autonSelected = false; //autonselected
            waitDisplay(); //waiting before starting odom
          }//activating whichever button is pressed
          break; //left

        case 2: //right tab
          //getting the button location
          for (int z = 0; z < 9; z++) {
              switch (z) {
                case 0:
                  string = "1G"; //button text
                  str = "Right - 1 Goal - is running."; //brain text
                  auton = 0; //auton selected
                  waitDisplay();
                  break;
                case 1:
                  string = "2G";
                  str = "Right - 2 Goals - is running.";
                  auton = 1;
                  break;
                case 2:
                  string = "3G";
                  str = "Right - 3 Goals - is running.";
                  auton = 2;
                  break;
                case 3:
                  string = "1GM";
                  str = "Right - 1 goal w/mid - is running.";
                  auton = 3;
                  break;
                case 4:
                  string = "2GM";
                  str = "Right - 2 goal w/mid - is running.";
                  auton = 4;
                  break;
                case 5:
                  string = "1GMs";
                  str = "Right - 1 goal w/midside - is running.";
                  auton = 5;
                  break;
                case 6:
                  string = "1GMsM";
                  str = "Right - 1 goal w/midside&mid - is running.";
                  auton = 6;
                  break;
                case 7:
                  string = "Depl";
                  str = "Right - No Auton w/Deploy - is running.";
                  auton = 7;
                  break;
                case 8:
                  string = "None";
                  str = "Right - No Auton - is running.";
                  auton = 8;
                  break;
              }//getting the button location and text
              //declaring the first and second x for the button
              if (z == 6) { y += (ht*2.4) * 1.5; fx = 30; } //if firs line not pressed, move to second line
              sx = fx + (string.length()*wd) + 20; //x coordinate of the right side of the button
              if ( (xPos >= fx && xPos <= sx) && (yPos >= y && yPos <= (y + (ht*2.4))) ) { Pressed = true; z = 100; } //testing if this button is pressed and stopping loop if so
              fx += ((string.length()*wd) + 20) + 10; //moving to the next button
          }//figuring out if/which button is pressed
          if (Pressed) {
            switch (auton) {
                case 0:
                  Competition.autonomous( g1Right ); //setting autonomous
                  break;
                case 1:
                  Competition.autonomous( g2Right ); //setting autonomous
                  break;
                case 2:
                  Competition.autonomous( g3Right ); //setting autonomous
                  break;
                case 3:
                  Competition.autonomous( g1MRight ); //setting autonomous
                  break;
                case 4:
                  Competition.autonomous( g2MRight ); //setting autonomous
                  break;
                case 5:
                  Competition.autonomous( g1MsRight ); //setting autonomous
                  break;
                case 6:
                  Competition.autonomous( g1MsMRight ); //setting autonomous
                  break;
                case 7:
                  Competition.autonomous( deploy ); //setting autonomous
                  break;
                case 8:
                  Competition.autonomous( nAuton ); //setting autonomous
                  break;
            }//setting the correct autonomous
            Brain.Screen.clearScreen(); //clearing screen
            Brain.Screen.setCursor(1,1); //starting at origin
            updateOutline(3); //creating white outline
            Brain.Screen.setPenColor(white); //showing which team is selected
            Brain.Screen.print(str); //displaying which auton is running
            autonSelected = false; //autonselected
            waitDisplay(); //waiting before starting odom
          }//activating whichever button is pressed
          break; //right

        default: //skills tab
          if (xPos <= 210 && xPos >= 30) {
            Competition.autonomous( skills ); //setting autonomous to skills autonomous
            Brain.Screen.clearScreen(); //clearing screen
            Brain.Screen.setCursor(1,1); //starting at origin
            Brain.Screen.setPenColor(white); //showing which team is selected
            updateOutline(3); //creating white outline
            Brain.Screen.print("Skills Autonomous is Running"); //displaying which auton is running
            waitDisplay();
            autonSelected = false; //autonselected
            waitDisplay(); //waiting before starting odom
          }//Run Skills button pressed
          break; //skills autonomous
    }
  }//if the screen is pressed and the auton isn't selected

  //debugging for the buttons, creates a circle where pressed and rectangles around hit boxes
    //Brain.Screen.drawRectangle(fx, y, sx-fx, (ht*2.4), blue);
    //Brain.Screen.drawCircle(xPos, yPos, 10, red);
    //task::sleep(500);

}//this will check which button has been pressed on the v5 brain screen